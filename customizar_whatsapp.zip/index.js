import express from "express";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config();

const app = express();
app.use(express.json());

const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// Webhook verification
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  } else {
    return res.sendStatus(403);
  }
});

// Receiving messages
app.post("/webhook", async (req, res) => {
  try {
    const body = req.body;

    if (
      body.object &&
      body.entry &&
      body.entry[0].changes &&
      body.entry[0].changes[0].value.messages &&
      body.entry[0].changes[0].value.messages[0]
    ) {
      const message = body.entry[0].changes[0].value.messages[0];
      const from = message.from;
      const userText = message.text?.body || "[Mensagem não textual]";

      const iaResponse = await callIA_Customizar(userText);
      await sendWhatsAppText(from, iaResponse);

      return res.sendStatus(200);
    } else {
      return res.sendStatus(200);
    }
  } catch (error) {
    console.error("Erro no webhook:", error.message);
    return res.sendStatus(500);
  }
});

// IA CUSTOMIZAR
async function callIA_Customizar(userMessage) {
  const systemPrompt = `
Você é a IA oficial da empresa CUSTOMIZAR — D DE S ARAUJO LTDA (CNPJ: 53.900.975/0001-32), especialista em Comunicação Visual, ACM, Estruturas Metálicas, LED e Precificação Industrial.
Responda de forma profissional, clara e objetiva.
  `;

  const userPrompt = `
Mensagem do cliente:
"${userMessage}"
  `;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.3,
      },
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    return "Sistema temporariamente indisponível. Tente novamente.";
  }
}

// Sending message to WhatsApp
async function sendWhatsAppText(to, text) {
  const url = `https://graph.facebook.com/v21.0/${PHONE_NUMBER_ID}/messages`;

  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: {
      preview_url: false,
      body: text,
    },
  };

  await axios.post(url, payload, {
    headers: {
      Authorization: `Bearer ${WHATSAPP_TOKEN}`,
      "Content-Type": "application/json",
    },
  });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Servidor CUSTOMIZAR WhatsApp rodando na porta " + PORT);
});
