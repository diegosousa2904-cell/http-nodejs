CUSTOMIZAR AI - WhatsApp Bot

Arquivos incluídos:
- index.js (servidor)
- package.json (dependências)
- .env (você cria no Railway)
- Código pronto para WhatsApp Cloud API + OpenAI

No Railway:
1. Crie novo projeto
2. Envie estes arquivos
3. Configure variáveis de ambiente:
   WHATSAPP_TOKEN=
   WHATSAPP_PHONE_NUMBER_ID=
   VERIFY_TOKEN=
   OPENAI_API_KEY=
   PORT=3000
4. Pegue a URL HTTPS gerada
5. Cole no Meta Developers → WhatsApp → Webhook
6. Pronto: IA CUSTOMIZAR funcionando no WhatsApp
